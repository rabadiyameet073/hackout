const express = require('express');
const {
  getReports,
  getReport,
  createReport,
  updateReport,
  deleteReport,
  uploadReportImages,
  joinReport,
  leaveReport,
  addComment,
  updateReportStatus,
  getReportsByLocation,
  exportReports
} = require('../controllers/reportController');

const { protect, authorize } = require('../middleware/auth');
const { validateReport, validateComment } = require('../middleware/validation');
const upload = require('../middleware/upload');

const router = express.Router();

// Public routes
router.get('/', getReports);
router.get('/location/:lat/:lng/:radius', getReportsByLocation);
router.get('/:id', getReport);

// Protected routes
router.use(protect);

router.post('/', validateReport, createReport);
router.post('/:id/images', upload.array('images', 5), uploadReportImages);
router.post('/:id/join', joinReport);
router.post('/:id/leave', leaveReport);
router.post('/:id/comments', validateComment, addComment);

// Admin/Moderator routes
router.put('/:id', authorize('admin', 'moderator'), updateReport);
router.delete('/:id', authorize('admin', 'moderator'), deleteReport);
router.patch('/:id/status', authorize('admin', 'moderator'), updateReportStatus);

// Admin only routes
router.get('/export/csv', authorize('admin'), exportReports);

module.exports = router;
