const express = require('express');
const {
  getDashboardStats,
  getReportAnalytics,
  getUserAnalytics,
  getLocationAnalytics,
  getTrendAnalytics,
  getPerformanceMetrics
} = require('../controllers/analyticsController');

const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// All analytics routes require authentication
router.use(protect);

// Dashboard statistics
router.get('/dashboard', getDashboardStats);

// Detailed analytics (Admin/Moderator only)
router.get('/reports', authorize('admin', 'moderator'), getReportAnalytics);
router.get('/users', authorize('admin', 'moderator'), getUserAnalytics);
router.get('/locations', authorize('admin', 'moderator'), getLocationAnalytics);
router.get('/trends', authorize('admin', 'moderator'), getTrendAnalytics);
router.get('/performance', authorize('admin', 'moderator'), getPerformanceMetrics);

module.exports = router;
