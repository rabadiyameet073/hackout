const mongoose = require('mongoose');
require('dotenv').config();

const User = require('../models/User');
const Report = require('../models/Report');
const Activity = require('../models/Activity');

async function clearDatabase() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    
    console.log('🔄 Clearing all data...');
    
    await User.deleteMany({});
    await Report.deleteMany({});
    await Activity.deleteMany({});
    
    console.log('✅ Database cleared successfully!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Clear failed:', error);
    process.exit(1);
  }
}

clearDatabase();
