const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('../models/User');
const Report = require('../models/Report');

async function seedDatabase() {
  try {
    // Connect to database
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });

    console.log('🔄 Clearing existing data...');
    
    // Clear existing data
    await User.deleteMany({});
    await Report.deleteMany({});

    console.log('👤 Creating users...');
    
    // Create sample users
    const hashedPassword = await bcrypt.hash('password123', 10);
    
    const users = await User.insertMany([
      {
        name: 'Admin User',
        email: 'admin@mangrovewatch.com',
        password: hashedPassword,
        role: 'admin',
        isActive: true,
        emailVerified: true,
        profile: {
          phone: '+63-917-123-4567',
          location: 'Manila, Philippines',
          bio: 'Environmental administrator and mangrove conservation advocate.',
          organization: 'MangroveWatch Foundation'
        },
        stats: {
          reportsSubmitted: 5,
          reportsVerified: 25,
          activitiesJoined: 3
        }
      },
      {
        name: 'Dr. Maria Santos',
        email: 'maria.santos@research.ph',
        password: hashedPassword,
        role: 'moderator',
        isActive: true,
        emailVerified: true,
        profile: {
          phone: '+63-917-234-5678',
          location: 'Quezon City, Philippines',
          bio: 'Marine biologist specializing in mangrove ecosystems.',
          organization: 'Philippine Marine Research Institute'
        },
        stats: {
          reportsSubmitted: 12,
          reportsVerified: 8,
          activitiesJoined: 7
        }
      },
      {
        name: 'Carlos Rodriguez',
        email: 'carlos@volunteer.org',
        password: hashedPassword,
        role: 'volunteer',
        isActive: true,
        emailVerified: true,
        profile: {
          phone: '+63-917-345-6789',
          location: 'Bataan, Philippines',
          bio: 'Local fisherman and environmental volunteer.',
          organization: 'Bataan Fisherfolk Association'
        },
        stats: {
          reportsSubmitted: 8,
          reportsVerified: 2,
          activitiesJoined: 12
        }
      },
      {
        name: 'Sarah Chen',
        email: 'sarah.chen@ngo.org',
        password: hashedPassword,
        role: 'volunteer',
        isActive: true,
        emailVerified: true,
        profile: {
          phone: '+63-917-456-7890',
          location: 'Palawan, Philippines',
          bio: 'Environmental activist and photographer.',
          organization: 'Green Palawan Initiative'
        },
        stats: {
          reportsSubmitted: 15,
          reportsVerified: 5,
          activitiesJoined: 9
        }
      },
      {
        name: 'Roberto Dela Cruz',
        email: 'roberto@coastal.ph',
        password: hashedPassword,
        role: 'volunteer',
        isActive: true,
        emailVerified: true,
        profile: {
          phone: '+63-917-567-8901',
          location: 'Bohol, Philippines',
          bio: 'Coastal community leader and mangrove restoration expert.',
          organization: 'Bohol Coastal Management'
        },
        stats: {
          reportsSubmitted: 6,
          reportsVerified: 3,
          activitiesJoined: 15
        }
      }
    ]);

    console.log('📊 Creating sample reports...');

    // Create sample reports
    const reports = [
      {
        title: 'Massive Mangrove Deforestation in Manila Bay',
        description: 'Large-scale clearing of mangrove forests observed in the northern section of Manila Bay. Estimated 50+ hectares affected with heavy machinery present.',
        location: {
          name: 'Manila Bay North',
          coordinates: {
            latitude: 14.5995,
            longitude: 120.9842
          },
          address: 'Barangay Navotas, Metro Manila',
          region: 'Metro Manila',
          country: 'Philippines'
        },
        status: 'Urgent',
        priority: 'Critical',
        category: 'Deforestation',
        submittedBy: users[1]._id,
        verifiedBy: users[0]._id,
        volunteers: [
          { user: users[2]._id, role: 'Expert' },
          { user: users[3]._id, role: 'Observer' }
        ],
        tags: ['deforestation', 'manila-bay', 'urgent', 'large-scale'],
        severity: 9,
        estimatedImpact: {
          area: 500000, // 50 hectares in square meters
          affectedSpecies: ['Rhizophora apiculata', 'Avicennia marina', 'Sonneratia alba'],
          economicImpact: 2500000
        },
        followUpRequired: true,
        followUpDate: new Date('2025-09-15'),
        comments: [
          {
            user: users[0]._id,
            message: 'This requires immediate attention. Coordinating with local authorities.',
            createdAt: new Date('2025-08-20')
          },
          {
            user: users[2]._id,
            message: 'I can provide local community support for restoration efforts.',
            createdAt: new Date('2025-08-21')
          }
        ]
      },
      {
        title: 'Oil Spill Contamination in Subic Bay',
        description: 'Oil spill detected near mangrove areas in Subic Bay. Dark patches visible on water surface and mangrove roots showing signs of oil contamination.',
        location: {
          name: 'Subic Bay Mangroves',
          coordinates: {
            latitude: 14.8167,
            longitude: 120.2833
          },
          address: 'Subic Bay, Zambales',
          region: 'Central Luzon',
          country: 'Philippines'
        },
        status: 'Verified',
        priority: 'High',
        category: 'Pollution',
        submittedBy: users[3]._id,
        verifiedBy: users[1]._id,
        volunteers: [
          { user: users[4]._id, role: 'Helper' },
          { user: users[2]._id, role: 'Observer' }
        ],
        tags: ['oil-spill', 'pollution', 'subic-bay', 'contamination'],
        severity: 8,
        estimatedImpact: {
          area: 75000,
          affectedSpecies: ['Rhizophora mucronata', 'Ceriops tagal'],
          economicImpact: 1200000
        },
        followUpRequired: true,
        followUpDate: new Date('2025-09-01'),
        resolution: {
          status: 'In Progress',
          description: 'Cleanup crews deployed. Oil boom barriers installed.',
          completedBy: users[0]._id
        }
      },
      {
        title: 'Illegal Fish Pen Construction in Laguna de Bay',
        description: 'Multiple illegal fish pens constructed in protected mangrove zones. Structures blocking natural water flow and damaging root systems.',
        location: {
          name: 'Laguna de Bay East',
          coordinates: {
            latitude: 14.3500,
            longitude: 121.3000
          },
          address: 'Cardona, Rizal',
          region: 'Calabarzon',
          country: 'Philippines'
        },
        status: 'Pending',
        priority: 'Medium',
        category: 'Wildlife',
        submittedBy: users[4]._id,
        volunteers: [
          { user: users[1]._id, role: 'Expert' }
        ],
        tags: ['illegal-construction', 'fish-pen', 'laguna-de-bay'],
        severity: 6,
        estimatedImpact: {
          area: 25000,
          affectedSpecies: ['Nypa fruticans', 'Rhizophora apiculata'],
          economicImpact: 300000
        },
        followUpRequired: true
      },
      {
        title: 'Mangrove Restoration Success in Palawan',
        description: 'Successful mangrove restoration project completed. Over 10,000 seedlings planted with 85% survival rate after 6 months.',
        location: {
          name: 'Puerto Princesa Bay',
          coordinates: {
            latitude: 9.7392,
            longitude: 118.7354
          },
          address: 'Puerto Princesa, Palawan',
          region: 'Mimaropa',
          country: 'Philippines'
        },
        status: 'Verified',
        priority: 'Low',
        category: 'Climate Change',
        submittedBy: users[3]._id,
        verifiedBy: users[1]._id,
        volunteers: [
          { user: users[4]._id, role: 'Expert' },
          { user: users[2]._id, role: 'Helper' },
          { user: users[0]._id, role: 'Observer' }
        ],
        tags: ['restoration', 'success', 'palawan', 'seedlings'],
        severity: 2,
        estimatedImpact: {
          area: 100000,
          affectedSpecies: ['Rhizophora stylosa', 'Bruguiera gymnorrhiza'],
          economicImpact: -500000 // Positive impact (carbon sequestration value)
        },
        resolution: {
          status: 'Completed',
          description: '10,000 mangrove seedlings successfully planted with community participation.',
          completedAt: new Date('2025-08-15'),
          completedBy: users[3]._id
        }
      },
      {
        title: 'Coastal Erosion Threatening Mangrove Forest',
        description: 'Severe coastal erosion observed in Bohol coastline. Mangrove trees falling into sea due to undermined root systems.',
        location: {
          name: 'Bohol East Coast',
          coordinates: {
            latitude: 9.8349,
            longitude: 124.1896
          },
          address: 'Anda, Bohol',
          region: 'Central Visayas',
          country: 'Philippines'
        },
        status: 'Urgent',
        priority: 'High',
        category: 'Climate Change',
        submittedBy: users[4]._id,
        volunteers: [
          { user: users[1]._id, role: 'Expert' },
          { user: users[3]._id, role: 'Observer' }
        ],
        tags: ['erosion', 'climate-change', 'bohol', 'urgent'],
        severity: 7,
        estimatedImpact: {
          area: 35000,
          affectedSpecies: ['Sonneratia caseolaris', 'Avicennia officinalis'],
          economicImpact: 800000
        },
        followUpRequired: true,
        followUpDate: new Date('2025-09-10')
      },
      {
        title: 'Water Quality Improvement in Restored Area',
        description: 'Significant improvement in water quality observed in recently restored mangrove area. pH levels normalized and fish population increasing.',
        location: {
          name: 'Bataan Mangrove Park',
          coordinates: {
            latitude: 14.6417,
            longitude: 120.4814
          },
          address: 'Mariveles, Bataan',
          region: 'Central Luzon',
          country: 'Philippines'
        },
        status: 'Verified',
        priority: 'Low',
        category: 'Water Quality',
        submittedBy: users[2]._id,
        verifiedBy: users[1]._id,
        volunteers: [
          { user: users[4]._id, role: 'Expert' }
        ],
        tags: ['water-quality', 'improvement', 'bataan', 'restoration'],
        severity: 3,
        estimatedImpact: {
          area: 15000,
          affectedSpecies: ['Various fish species', 'Crustaceans'],
          economicImpact: -200000 // Positive economic impact
        },
        resolution: {
          status: 'Completed',
          description: 'Water quality monitoring shows positive trends. Ecosystem recovery on track.',
          completedAt: new Date('2025-08-10'),
          completedBy: users[1]._id
        }
      }
    ];

    await Report.insertMany(reports);

    console.log('✅ Sample data created successfully!');
    console.log(`👥 Created ${users.length} users`);
    console.log(`📊 Created ${reports.length} reports`);
    console.log('\n🔐 Login credentials:');
    console.log('📧 Email: admin@mangrovewatch.com');
    console.log('🔑 Password: password123');
    console.log('\n🚀 You can now start the server and test the API!');

    process.exit(0);
  } catch (error) {
    console.error('❌ Seeding failed:', error);
    process.exit(1);
  }
}

// Run the seeding function
seedDatabase();
